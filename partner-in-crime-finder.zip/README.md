
# 🎉 Partner In Crime Finder

A fun web tool built using HTML, CSS, and Google Apps Script that helps users discover their party partner!

## Features
- Elegant UI with glassmorphism effect
- Google Apps Script backend integration
- Mobile-responsive design

## Tools Used
- HTML5 / CSS3 / JavaScript
- Google Apps Script

## License
MIT
