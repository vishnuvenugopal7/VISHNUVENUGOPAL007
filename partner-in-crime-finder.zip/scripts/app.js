
function findPartner() {
  document.getElementById('result').innerText = "Your partner is loading...";
  google.script.run.withSuccessHandler(function(response) {
    document.getElementById('result').innerText = response;
  }).getPartner();
}
